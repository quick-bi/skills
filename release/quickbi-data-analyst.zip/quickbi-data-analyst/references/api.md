# 脚本接口契约（quickbi-data-analyst 问数/HTML 报告/仪表板）

当前唯一入口脚本，Python 3.8+ 标准库即可运行：

- `scripts/chat.py`：问数（文字与 Markdown 表格）+ HTML 报告（终态 files 解析免登预览/下载链接）+ 仪表板生成（`--dashboard`，解析 artifact-dashboard 产物并换票输出预览链接）

依赖同目录基础模块（按机制拆分，后续新入口脚本共用）：`config_loader.py`（三级凭证加载）、`gateway.py`（签名/SSL/HTTP/错误映射）、`stream.py`（SSE 分段消费）、`output.py`（输出契约）。

## 通用约定

- **stdout** 只输出本契约定义的 JSON；**stderr** 为过程日志（回复增量、事件、重连），不属于契约，调用方可忽略
- **退出码**：`0` 成功 / `1` 业务失败 / `2` 配置或参数错误
- **失败出参**：

```json
{
  "connected": false,
  "error": {
    "code": "错误码，见文末错误码表",
    "message": "错误详情",
    "suggestion": "处理建议",
    "traceId": "报障用链路 ID（可能为空）"
  }
}
```

## 鉴权

- 签名：`X-Gw-AccessId` / `X-Gw-Nonce` / `X-Gw-Timestamp` / `X-Gw-Signature` 四头 HmacSHA256（签名串 = METHOD + URI + 排序后 query + X-Gw 头，RFC3986 编码后 HMAC-SHA256 + base64；body 不参与签名）
- 凭证：三级来源，`QUICKBI_*` 环境变量 > `<workspace>/.qbi/config.yaml` > `~/.qbi/config.yaml`（详见 `setup.md`），**无试用凭证**；`api_key`/`api_secret` 必须为个人级 AK
- 提交请求 body 恒携带 `user_id`，值即个人级 AccessId（`api_key`），服务端以该用户身份取数

## 入参

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `--message` | string | - | 用户问题原文（纯文本）。**脚本会自动在前面拼接系统提示词**，故可用长度 = 10000 − 提示词前缀长度，超限报 `CONFIG_MISSING`（exit 2） |
| `--dashboard` | flag | 关 | 仪表板生成轮次：系统提示词改为约束服务端用 `qbi-dashboard-builder` 产出仪表板产物；纯问数轮次不要加。只影响提交，续读无需携带 |
| `--session-id` | string | - | 复用会话（多轮上下文 / 继续读取同一轮结果），值来自上一轮出参 `sessionId` |
| `--conversation-id` | string | - | 只挂流不提交（断点恢复），值来自本次提交的 `conversationId` |
| `--workspace-dir` | path | `WORKSPACE_DIR` 环境变量或当前目录 | 用户工作目录：决定工作目录级配置层 `<dir>/.qbi/config.yaml` |
| `--timeout` | int | 300 | 总超时秒数（宿主命令执行超时建议设 300000ms） |
| `--max-reconnects` | int | 3 | SSE 断线最大重连次数（指数退避，上限 30s） |
| `--stream-step` | flag | 关 | 分段拉取模式：`message.stop` 先缓存 text，后续非 complete 事件到达时返回 `partial`；若直接到达 `message.complete`，以 complete 为最终结果并避免重复展示，适合脚本 tool 不能实时透传 stdout 的 agent 平台 |
| `--cursor` | string | - | `--stream-step` 续传游标，传上一段返回的 `cursor`（SSE event id / Last-Event-ID） |
| `--cancel` | flag | 关 | 取消进行中的对话（必须 `--session-id` 指定） |
| `--submit-timeout` | int | 60 | 提交请求超时秒数 |
| `--no-guard` | flag | 关 | **仅排障用**：不拼接系统提示词，正常链路不要使用 |

组合规则：

- `--message` 与 `--conversation-id` 至少提供其一（前者提交新问题，后者继续读取同一轮结果）
- 只用 `--conversation-id` 继续读取结果时，也要同时传 `--session-id <sessionId>`，用于保持同一会话上下文
- `--stream-step` 首次可与 `--message` 一起使用；后续用 `--conversation-id <cid> --cursor <cursor> --session-id <sessionId> --stream-step` 继续拉下一段
- `--cancel` 为独立模式：必须配 `--session-id` 指定要取消的会话

## 提示词拼接模型（脚本自动处理，每轮提交都带）

提交给服务端的 message = 系统提示词（通用边界 + 模式规则）+ 用户问题原文。

- 通用边界固定在 `chat.py` 中：能力范围限定问数、HTML 报告与仪表板、禁止资产同步与建模/配置类操作及代码/文件导出等其他产物形式、数据结论用 Markdown 表格、禁止不可渲染的交互组件（卡片/按钮/下拉）
- 模式规则按 `--dashboard` 切换：默认问数轮次（只输出文字与表格，不生成产物；用户明确要求 HTML 报告/页面时用 `qbi-grounded-report` 生成单文件 HTML 报告，结构与皮肤用默认值、不发起交互确认）；`--dashboard` 轮次（必须用 `qbi-dashboard-builder` 生成仪表板产物，不路由到 ai_html 等其他形式）

系统提示词与用户问题共享服务端 10000 字符上限。脚本按提示词前缀长度计算用户问题可用预算，超限报 `CONFIG_MISSING`。

## 出参：分段流式模式（`--stream-step`，stdout 单个 JSON）

每次调用读取到最终完成事件，或一批暂不可展示事件后返回；`message.stop` 先缓存该 block 的 text，不立即展示，等后续事件决定是否回显：

```json
{
  "type": "stream_step",
  "connected": true,
  "status": "running",
  "final": false,
  "sessionId": "会话 ID，多轮追问时回传 --session-id",
  "conversationId": "本次对话 ID，下一段回传 --conversation-id",
  "cursor": "1785898107339-0",
  "events": 12,
  "text": ""
}
```

- `sessionId` 回显本次传入的 `--session-id`：`--conversation-id` 继续读取场景下必须同时传 `--session-id`（见组合规则），此时回显的即当前有效会话 ID；后续无论继续读取结果、分段拉取下一段，还是多轮追问，都应继续传 `--session-id`
- `status=partial`：后续非 complete 事件触发上一段 `message.stop` 缓存文本的回显；若返回非空 `text`，调用方先原样展示，再带同一 `conversationId`、`cursor` 与 `sessionId` 继续调用 `--stream-step`
- `status=running`：本次只读到工具调用、心跳，或刚遇到 `message.stop` 并已缓存当前 text block；不向用户展示，继续用返回的 `cursor` 拉下一段
- `status=done`：`text` / `reply` 是最终答案（终态检出 `.html` 交付文件时另有 `html`）；若后续直接到达 `message.complete`，脚本不会额外回显前一个 stop 缓存文本，避免重复展示；原样展示并结束本轮
- `cursor` 是已处理完的最后一个 SSE event id，下一次作为 `--cursor` 传回，避免重复拼接
- 脚本只拼接 `message.delta`；`thinking.*`、`tool.*` 默认不展示；最终答案优先使用 `message.complete.data.result`
- `artifactFiltered: true`：text 中出现**非仪表板**产物标签或 HTML 内部注释（如 `<!--TABLE_TITLE:...-->`），脚本已过滤原文；照常展示 text/reply，不向用户提标签/产物

### 仪表板产物字段（`dashboard`，检出 artifact-dashboard 标签时携带）

服务端回复含 `<artifact-dashboard id="..." version="..." name="..." .../>` 标签时，脚本自动：① 从 text/reply 过滤该标签；② 调用换票接口 `POST /openapi/v2/abi/artifacts/embed-ticket`（body: `artifact_id` / `expire_minutes` / `ticket_num`，后两者来自 Skill 根目录 `settings.yaml`）签发免登票据；③ 把返回 `embed_url` 的 `artifactId` 参数改名为 `id` 并追加 `version`，得到预览链接；④ 按 `display_type` 预渲染可直接粘贴的展示片段：

```json
"dashboard": {
  "artifactId": "产物 ID（内部字段，勿展示）",
  "name": "看板名称（可展示）",
  "displayType": "iframe 或 markdown（来自 settings.yaml 的 display_type，默认 iframe）",
  "version": "产物版本（可能缺省）",
  "url": "免登预览链接（iframe src / Markdown 链接地址）",
  "render": "可直接粘贴的展示片段：iframe 模式为 iframe 标签 + 一行可点击链接兜底，markdown 模式为可点击链接",
  "expireAt": "票据过期时间"
}
```

- 换票失败不阻断主流程：`dashboard` 无 `url`/`render`，改携 `ticketError`（含 trace_id）；text/reply 照常展示，调用方降级为文字告知，**不要**自行拼接 URL
- 每次加载/刷新看板消耗一次票据次数；票据失效时用同一 `--session-id` 加 `--dashboard` 重新提问即可重新签票

### HTML 交付文件字段（`html`，终态检出 `.html` 文件时携带）

终态 `message.complete` 的 `data.files` 含交付文件列表（`name`/`type`/`path`/`preview`/`download`）。`qbi-grounded-report` 的发布产物为 `<报告标题>.report.html`（已通过确定性门禁与一次快速质检），与其余 `.html` 交付文件共用本通道。脚本自动：① 过滤出 `type` 以 html 结尾的交付文件（`.json` 为取数中间产物，不透出）；② 把相对路径 `preview`/`download` 拼上 gateway 前缀；③ 预渲染可直接粘贴的展示片段：

```json
"html": [
  {
    "name": "销售数据概览.report.html",
    "url": "https://<gateway>/api/v2/abi/storage/proxy/...（免登预览，disp=inline）",
    "download": "https://<gateway>/api/v2/abi/storage/proxy/...（下载，disp=attachment）",
    "render": "[📄 打开「销售数据概览.report.html」](https://<gateway>/...) "
  }
]
```

- `render` 为可点击链接的最终形态，调用方原样输出即可，不要用代码块包裹、不要改写链接
- 预览/下载链接 24 小时有效；过期时用同一 `--session-id` 重新提问即可重新产出
- 终态无 `.html` 文件时出参不带 `html` 字段；调用方照常展示 reply，不自行编造链接

## 出参：取消模式（`--cancel`）

```json
{ "cancelled": true, "sessionId": "被取消的会话 ID" }
```

---

# 错误码表

| 错误码 | HTTP | 含义 | 处理动作 |
| --- | --- | --- | --- |
| `AUTH_FAILED` | 401 | 签名校验失败 / AK 无效 / 时间戳过期 | 核对 api_key/api_secret 与本机时钟；见 setup.md |
| `AK_LEVEL_REJECTED` | 403 | 组织级/空间级 AK 或越权访问 | 更换**个人级** AK；检查资源归属 |
| `API_NOT_AUTHORIZED` | 403/200 | AK 未开通该接口授权 | 联系管理员在开放平台为 AK 授权 |
| `QUOTA_INSUFFICIENT` | 200 | 连通正常，租户 ABI 额度不足 | 联系管理员充值 |
| `RESOURCE_NOT_FOUND` | 404 | 资源不存在（conversation_id 有误或不归属当前用户） | 检查 ID 是否为本次提交返回值 |
| `PATH_NOT_FOUND` | 404 | 接口路径未注册（返回前端页面） | 该环境可能未部署对应 openapi，向后端确认 |
| `RATE_LIMITED` | 429 | 触发限流 | 退避后重试 |
| `INVALID_PARAMS` | 422 | 参数校验失败（FastAPI 原生 detail，退出码 2） | 对照本文检查参数取值与范围 |
| `NETWORK_ERROR` | - | 网络失败 / 请求超时 | 检查 server_domain 与网络连通性 |
| `SERVER_ERROR` | 5xx | 服务端错误（或网关返回 HTML） | 携 traceId 报障；降低并发后重试 |
| `BUSINESS_ERROR` | 200 | 网关级业务失败 / 服务端 error 事件 | 按 message 排查；携 traceId 报障 |
| `CONFIG_MISSING` | - | 配置缺失（server_domain/api_key/api_secret；settings.yaml 取值非法）、参数不完整、message 超长（退出码 2） | 按 message 补全配置（凭证走环境变量或 ~/.qbi/config.yaml；设置项修正 Skill 根目录 settings.yaml，见 setup.md）或精简内容 |
| `SSE_TIMEOUT` | - | 消费超时，**任务仍在后台执行** | `--conversation-id <本次 cid> --session-id <sessionId>` 继续读取，勿重新提交 |
| `SSE_RECONNECT_EXHAUSTED` | - | 重连耗尽，**任务仍在后台执行** | 同上，继续传本次 `sessionId`，保持同一会话上下文 |
| `ENV_NOT_ENABLED` | 200 | 该环境未开通该 API（AE0510010001/OE10010106） | 非 AK 问题：后端执行 init.sql 并等约 120s 配置缓存 |
